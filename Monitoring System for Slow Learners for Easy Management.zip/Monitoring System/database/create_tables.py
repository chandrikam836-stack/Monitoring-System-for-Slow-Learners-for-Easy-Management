import sqlite3

from db_connection import get_connection

conn = get_connection()

cursor = conn.cursor()

# ==========================================
# CREATE STUDENTS TABLE
# ==========================================
cursor.execute("""

 CREATE TABLE IF NOT EXISTS students (

    Student_ID TEXT PRIMARY KEY,

    Name TEXT,
    Department TEXT,

    SSC_Percentage INTEGER,
    Twelfth_Percentage INTEGER,

    First_Mid INTEGER,
    First_Sem INTEGER,

    Second_Mid INTEGER,
    Second_Sem INTEGER,

    Third_Mid INTEGER,
    Third_Sem INTEGER,

    Fourth_Mid INTEGER,
    Fourth_Sem INTEGER,

    Fifth_Mid INTEGER,
    Fifth_Sem INTEGER,

    Sixth_Mid INTEGER,
    Sixth_Sem INTEGER,

    Seventh_Mid INTEGER,
    Seventh_Sem INTEGER,

    Eighth_Mid INTEGER,
    Eighth_Sem INTEGER,

    Attendance INTEGER,
    Backlogs INTEGER,

    Hackathons INTEGER,
    Ideathons INTEGER,
    Quizzes INTEGER,
    Coding_Contests INTEGER,
    Workshops INTEGER,
    Certifications INTEGER,
    Sports INTEGER,
    NSS_NCC INTEGER,
    Clubs INTEGER,
    Projects INTEGER,

    Activity_Score INTEGER,
    Performance_Badge TEXT,
    Risk_Level TEXT

)

""")

conn.commit()

print("✅ Tables created successfully!")

conn.close()