import pandas as pd
from db_connection import get_connection

# ==========================================
# CONNECT DATABASE
# ==========================================
conn = get_connection()

# ==========================================
# LOAD CSV
# ==========================================
df = pd.read_csv(
    "data/students.csv"
)

# ==========================================
# INSERT INTO DATABASE
# ==========================================
df.to_sql(
    "students",
    conn,
    if_exists="replace",
    index=False
)

# ==========================================
# SUCCESS MESSAGE
# ==========================================
print("✅ Students inserted successfully!")

conn.close()