import sqlite3
import pandas as pd

conn = sqlite3.connect(
    "data/student_monitoring.db"
)

users = pd.DataFrame({

    "username": [
        "admin",
        "faculty1",
        "faculty2",
        "faculty3",
        "faculty4",
        "mentor1",
        "mentor2",
        "mentor3",
        "mentor4"
    ],

    "password": [
        "admin123",
        "fac123",
        "fac456",
        "fac789",
        "fac012",
        "mentor123",
        "mentor456",
        "mentor789",
        "mentor012"
    ],

    "role": [
        "Admin",
        "Faculty",
        "Faculty",
        "Faculty",
        "Faculty",
        "Mentor",
        "Mentor",
        "Mentor",
        "Mentor"
    ],

    "department": [
        "All",
        "CSE",
        "AIML",
        "ECE",
        "MECH",
        "CSE",
        "AIML",
        "ECE",
        "MECH"
    ]
})

users.to_sql(
    "users",
    conn,
    if_exists="replace",
    index=False
)

print("✅ Users inserted successfully!")

conn.close()