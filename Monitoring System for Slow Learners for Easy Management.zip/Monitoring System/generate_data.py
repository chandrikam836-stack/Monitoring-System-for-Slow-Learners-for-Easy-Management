import pandas as pd
import random
import os


# ==========================================
# CREATE FOLDER
# ==========================================
os.makedirs("data", exist_ok=True)

data = []

names = [
    "Ravi", "Anita", "Kiran", "Sita",
    "Rahul", "Priya", "Arjun", "Sneha",
    "Vikas", "Pooja", "Sai", "Deepika",
    "Harsha", "Nikhil", "Teja", "Divya"
]

departments = ["CSE", "AIML", "ECE", "MECH"]

# ==========================================
# GENERATE DATA
# ==========================================
for i in range(1, 1001):

    Department = random.choice(departments)

    Student_ID = f"{Department}{i:04d}"

    Name = random.choice(names)
   
    # ==========================
    # SLOW LEARNERS
    # ==========================
    if i <= 200:

        low = 35
        high = 60

        Attendance = random.randint(50, 70)
        Backlogs = random.randint(2, 5)

        Hackathons = random.randint(0, 1)
        Ideathons = random.randint(0, 1)
        Quizzes = random.randint(0, 2)
        Coding_Contests = random.randint(0, 1)
        Workshops = random.randint(0, 2)
        Certifications = random.randint(0, 1)
        Sports = random.randint(0, 1)
        NSS_NCC = random.randint(0, 1)
        Clubs = random.randint(0, 1)
        Projects = random.randint(0, 1)

    # ==========================
    # AVERAGE STUDENTS
    # ==========================
    elif i <= 800:

        low = 55
        high = 80

        Attendance = random.randint(70, 85)
        Backlogs = random.randint(0, 2)

        Hackathons = random.randint(0, 2)
        Ideathons = random.randint(0, 2)
        Quizzes = random.randint(1, 5)
        Coding_Contests = random.randint(0, 2)
        Workshops = random.randint(1, 4)
        Certifications = random.randint(1, 4)
        Sports = random.randint(0, 2)
        NSS_NCC = random.randint(0, 1)
        Clubs = random.randint(0, 2)
        Projects = random.randint(1, 3)

    # ==========================
    # FAST LEARNERS
    # ==========================
    else:

        low = 75
        high = 98

        Attendance = random.randint(85, 100)
        Backlogs = 0

        Hackathons = random.randint(2, 5)
        Ideathons = random.randint(1, 3)
        Quizzes = random.randint(4, 10)
        Coding_Contests = random.randint(2, 5)
        Workshops = random.randint(3, 8)
        Certifications = random.randint(3, 10)
        Sports = random.randint(1, 4)
        NSS_NCC = random.randint(0, 2)
        Clubs = random.randint(1, 5)
        Projects = random.randint(3, 6)

    # ==================================
    # ACADEMIC MARKS
    # ==================================
    SSC_Percentage = random.randint(low, high)
    Twelfth_Percentage = random.randint(low, high)

    First_Mid = random.randint(low, high)
    First_Sem = random.randint(low, high)

    Second_Mid = random.randint(low, high)
    Second_Sem = random.randint(low, high)

    Third_Mid = random.randint(low, high)
    Third_Sem = random.randint(low, high)

    Fourth_Mid = random.randint(low, high)
    Fourth_Sem = random.randint(low, high)

    Fifth_Mid = random.randint(low, high)
    Fifth_Sem = random.randint(low, high)

    Sixth_Mid = random.randint(low, high)
    Sixth_Sem = random.randint(low, high)

    Seventh_Mid = random.randint(low, high)
    Seventh_Sem = random.randint(low, high)

    Eighth_Mid = random.randint(low, high)
    Eighth_Sem = random.randint(low, high)

    # ==================================
    # ACTIVITY SCORE
    # ==================================
    Activity_Score = (
        Hackathons * 10 +
        Ideathons * 8 +
        Quizzes * 3 +
        Coding_Contests * 7 +
        Workshops * 4 +
        Certifications * 5 +
        Sports * 3 +
        NSS_NCC * 4 +
        Clubs * 2 +
        Projects * 10
    )

    # ==================================
    # PERFORMANCE BADGE
    # ==================================
    avg_marks = (
        First_Sem +
        Second_Sem +
        Third_Sem +
        Fourth_Sem +
        Fifth_Sem +
        Sixth_Sem +
        Seventh_Sem +
        Eighth_Sem
    ) / 8

    if avg_marks >= 80:
        Performance_Badge = "Top Performer"
    elif avg_marks >= 60:
        Performance_Badge = "Average"
    else:
        Performance_Badge = "Slow Learner"

    # ==================================
    # RISK LEVEL
    # ==================================
    if Attendance < 55 or Backlogs > 4:
        Risk_Level = "High Risk"
    elif Attendance < 75:
        Risk_Level = "Moderate Risk"
    else:
        Risk_Level = "Low Risk"

    # ==================================
    # STORE DATA
    # ==================================
    data.append([
       Student_ID,
       Name,
       Department,

       SSC_Percentage,
       Twelfth_Percentage,

       First_Mid,
       First_Sem,

       Second_Mid,
       Second_Sem,

       Third_Mid,
       Third_Sem,

       Fourth_Mid,
       Fourth_Sem,

       Fifth_Mid,
       Fifth_Sem,

       Sixth_Mid,
       Sixth_Sem,

       Seventh_Mid,
       Seventh_Sem,
 
       Eighth_Mid,
       Eighth_Sem,

       Attendance,
       Backlogs,

       Hackathons,
       Ideathons,
       Quizzes,
       Coding_Contests,
       Workshops,
       Certifications,
       Sports,
       NSS_NCC,
       Clubs,
       Projects,

       Activity_Score,
       Performance_Badge,
       Risk_Level
    ])
# ==========================================
# COLUMN NAMES
# ==========================================
columns = [
    "Student_ID",
    "Name",
    "Department",

    "SSC_Percentage",
    "Twelfth_Percentage",

    "First_Mid",
    "First_Sem",

    "Second_Mid",
    "Second_Sem",

    "Third_Mid",
    "Third_Sem",

    "Fourth_Mid",
    "Fourth_Sem",

    "Fifth_Mid",
    "Fifth_Sem",

    "Sixth_Mid",
    "Sixth_Sem",

    "Seventh_Mid",
    "Seventh_Sem",

    "Eighth_Mid",
    "Eighth_Sem",

    "Attendance",
    "Backlogs",

    "Hackathons",
    "Ideathons",
    "Quizzes",
    "Coding_Contests",
    "Workshops",
    "Certifications",
    "Sports",
    "NSS_NCC",
    "Clubs",
    "Projects",

    "Activity_Score",
    "Performance_Badge",
    "Risk_Level"
]

# ==========================================
# DATAFRAME
# ==========================================
df = pd.DataFrame(data, columns=columns)
before_btech_cols = [
    "Student_ID",
    "Name",
    "Department",
    "SSC_Percentage",
    "Twelfth_Percentage"
]

df[before_btech_cols].to_csv(
    "data/before_btech.csv",
    index=False
)
first_year_cols = [
    "Student_ID",
    "Name",
    "Department",
    "SSC_Percentage",
    "Twelfth_Percentage",
    "First_Mid",
    "First_Sem",
    "Second_Mid",
    "Second_Sem"
]

df[first_year_cols].to_csv(
    "data/first_year.csv",
    index=False
)
second_year_cols = [
    "Student_ID",
    "Name",
    "Department",
    "SSC_Percentage",
    "Twelfth_Percentage",
    "First_Mid",
    "First_Sem",
    "Second_Mid",
    "Second_Sem",
    "Third_Mid",
    "Third_Sem",
    "Fourth_Mid",
    "Fourth_Sem"
]

df[second_year_cols].to_csv(
    "data/second_year.csv",
    index=False
)
third_year_cols = [
    "Student_ID",
    "Name",
    "Department",
    "SSC_Percentage",
    "Twelfth_Percentage",
    "First_Mid",
    "First_Sem",
    "Second_Mid",
    "Second_Sem",
    "Third_Mid",
    "Third_Sem",
    "Fourth_Mid",
    "Fourth_Sem",
    "Fifth_Mid",
    "Fifth_Sem",
    "Sixth_Mid",
    "Sixth_Sem"
]

df[third_year_cols].to_csv(
    "data/third_year.csv",
    index=False
)
final_year_cols = [
    "Student_ID",
    "Name",
    "Department",
    "SSC_Percentage",
    "Twelfth_Percentage",
    "First_Mid",
    "First_Sem",
    "Second_Mid",
    "Second_Sem",
    "Third_Mid",
    "Third_Sem",
    "Fourth_Mid",
    "Fourth_Sem",
    "Fifth_Mid",
    "Fifth_Sem",
    "Sixth_Mid",
    "Sixth_Sem",
    "Seventh_Mid",
    "Seventh_Sem",
    "Eighth_Mid",
    "Eighth_Sem"
]

df[final_year_cols].to_csv(
    "data/final_year.csv",
    index=False
)
# ==========================================
# SAVE CSV
# ==========================================
df.to_csv("data/students.csv", index=False)

print("✅ Dataset created successfully")
print(df.head())